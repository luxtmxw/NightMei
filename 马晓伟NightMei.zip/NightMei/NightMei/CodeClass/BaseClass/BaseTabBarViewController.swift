//
//  BaseTabBarViewController.swift
//  NightMei
//
//  Created by luxtmxw on 16/10/1.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit

class BaseTabBarViewController: UITabBarController {

    var xwTabBar: XwTabBar!
    var window: UIWindow!
    var midView: UIView!
    var naVC: UINavigationController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(animated: Bool) {
        //全局设置导航条
        UINavigationBar.appearance().lt_setBackgroundColor(Color_35)
        UINavigationBar.appearance().shadowImage = UIImage()
//        UINavigationBar.appearance().tintColor = Color_666
        UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        UIApplication.sharedApplication().setStatusBarStyle(UIStatusBarStyle.LightContent, animated: true)//        navigationController?.navigationBar.lt_setBackgroundColor(Color_333)
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.Done, target: nil, action: nil)
    }

    func setupView() {
        xwTabBar = XwTabBar(frame: CGRectMake(0, 0, kScreenWidth, 59.5), target: self, btnAction: "btnAction")
        self.setValue(xwTabBar, forKey: "tabBar")
        
        let homeVC = HomeViewController()
        self.addVC(homeVC, titleName: "主页", selectedImageName: "20", imageName: "20(2)")
        
        let messageVC = OtherViewController()
        self.addVC(messageVC, titleName: "消息", selectedImageName: "30", imageName: "30(2)")
        
        let friendVC = OtherViewController()
        self.addVC(friendVC, titleName: "好友", selectedImageName: "60", imageName: "60(2)")
        
        let mineVC = OtherViewController()
        self.addVC(mineVC, titleName: "我的", selectedImageName: "70", imageName: "70(2)")
        
        xwTabBar.tintColor = Color_206
//        UITabBar.appearance().backgroundImage = UIImage(named: "0")
        
    }
    
    func addVC(childVC: UIViewController, titleName: String, selectedImageName: String, imageName: String) {
        childVC.title = titleName
        childVC.tabBarItem.image = UIImage(named: imageName)
        childVC.tabBarItem.selectedImage = UIImage(named: selectedImageName)?.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        childVC.tabBarItem.imageInsets = UIEdgeInsetsMake(6, 0, -6, 0)
        childVC.tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -2)
        naVC = UINavigationController(rootViewController: childVC)
        self.addChildViewController(naVC)
    }
    
    func btnAction() {
        let middleVC = MiddleViewController()
        let navi = UINavigationController(rootViewController: middleVC)
        presentViewController(navi, animated: false, completion: nil)
    }
    
    func bottonBtnAction() {
        UIView.animateWithDuration(0.3, delay: 0.5, options: UIViewAnimationOptions.AllowAnimatedContent, animations: {
            self.midView.alpha = 0
            }, completion: { (fin) in
                self.midView.removeFromSuperview()
        })
    }
    
    func setupMidView() {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
