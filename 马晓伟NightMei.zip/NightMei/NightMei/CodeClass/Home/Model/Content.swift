//
//  content.swift
//  NightMei
//
//  Created by luxtmxw on 16/10/1.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import SwiftyJSON

class Content: NSObject {
    var imgUrl: String!
    var title: String!
    
    convenience init(json: JSON) {
        self.init()
        self.imgUrl = json["smallIcon"].stringValue
        self.title = json["shortName"].string
    }
}
