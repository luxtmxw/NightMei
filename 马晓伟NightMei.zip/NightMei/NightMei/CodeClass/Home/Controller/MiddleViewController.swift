//
//  MiddleViewController.swift
//  NightMei
//
//  Created by luxtmxw on 16/10/2.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit

class MiddleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.whiteColor()
        setLeftBarBtn()
        // Do any additional setup after loading the view.
    }

    func setLeftBarBtn() {
        let leftBarBtn = UIBarButtonItem(title: "返回", style: UIBarButtonItemStyle.Done, target: self, action: "leftBarBtnAction")
        navigationItem.leftBarButtonItem = leftBarBtn
    }
    
    func leftBarBtnAction() {
        dismissViewControllerAnimated(false, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
