//
//  HomeViewController.swift
//  NightMei
//
//  Created by luxtmxw on 16/10/1.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import MJRefresh

class HomeViewController: UIViewController {

    var turnPlayView: TurnPlayView! //轮播图
    var tableView: UITableView!
    var sessionID: String!
    var banners = [Banner]()
    var imgs = [String]()
    var contents = [Content]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        view.backgroundColor = UIColor.redColor()
        debugPrint("主页")
        setBarBtn()
        setTableView()
        setRefrseh()
        tableView.mj_header.beginRefreshing()
        loginRequest()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        if turnPlayView.timer != nil {
            turnPlayView.duration = 4
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        if turnPlayView.timer != nil {
            turnPlayView.timer.invalidate()
        }
    }
    
    
    //MARK - 设置导航条按钮
    func setBarBtn() {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: " ", style: .Done, target: nil, action: nil)
        
        let leftImage = UIImage(named: "kefu")
        let leftBtn = UIButton(frame: CGRectMake(0,0,(leftImage?.imgWidth())!,(leftImage?.imgHeight())!))
        leftBtn.buttonInitWithImage("kefu", target: self, action: "barBtnAction")
        
        let middleImage = UIImage(named: "8")
        let middleBtn = UIButton(frame: CGRectMake(0,0,(middleImage?.imgWidth())!,(middleImage?.imgHeight())!))
        middleBtn.buttonInitWithImage("8", target: self, action: "barBtnAction")
        
        let rightImage = UIImage(named: "7")
        let rightBtn = UIButton(frame: CGRectMake(0,0,(rightImage?.imgWidth())!,(rightImage?.imgHeight())!))
        rightBtn.buttonInitWithImage("7", target: self, action: "barBtnAction")
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: leftBtn)
        navigationItem.titleView = middleBtn
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: rightBtn)
        
    }
    
    //MARK - 设置轮播图
    func setTurnView() {
        turnPlayView = TurnPlayView(frame: CGRectMake(0, 0, view.bounds.width, 200.Sh()))
        turnPlayView.delegate = self
    }
    
    func setTableView() {
        
        setTurnView()
        
        tableView = UITableView(frame: CGRectMake(0,0,kScreenWidth,kScreenHeight - 49))
        tableView.backgroundColor = Color_EEEEEE
        tableView.rowHeight = 177.Sh()
        tableView.registerClass(ContentTableViewCell.self, forCellReuseIdentifier: "contentCell")
        tableView.separatorStyle = .None
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableHeaderView = turnPlayView
        view.addSubview(tableView)
    }
    
    //MARK - 设置下拉
    func setRefrseh() {
        let header = MJRefreshGifHeader(refreshingTarget: self, refreshingAction: "loginRequest")
//        header.backgroundColor = UIColor.whiteColor()
//        header.stateLabel?.hidden = true
        tableView.mj_header = header
    }
    
    //MARK - 登录
    func loginRequest() {
        HomeServerInstance.login({ (sessionID) -> Void in
            self.sessionID = sessionID
            self.swiperRequest()
            }) { () -> Void in
                self.popView()
                print("11")
                self.tableView.mj_header.endRefreshing()
        }
    }
    
    //MARK - 轮播
    func swiperRequest() {
        HomeServerInstance.getSwiper(self.sessionID, succeed: { (banners) -> Void in
            self.banners = banners
            self.categoryRequest()
            
            self.turnPlayView.banners = self.banners
            self.turnPlayView.duration = 4.0
            }) { () -> Void in
                self.tableView.mj_header.endRefreshing()
        }
    }
    
    //MARK - 分类
    func categoryRequest() {
        HomeServerInstance.getCategory(self.sessionID, succeed: { (contents) -> Void in
            self.contents = contents
            self.tableView.mj_header.endRefreshing()
            self.tableView.reloadData()
            }) { () -> Void in
                self.tableView.mj_header.endRefreshing()
        }
    }
    
    //MARK - 提示
    func popView() {
        let alert = UIAlertController(title: "提示", message: "网络连接错误", preferredStyle: UIAlertControllerStyle.Alert)
        let sure = UIAlertAction(title: "确定", style: UIAlertActionStyle.Default, handler: nil)
        alert.addAction(sure)
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func barBtnAction() {
        self.pushToOtherController()
    }
    
    func pushToOtherController() {
        let otherVC = OtherViewController()
        self.navigationController?.pushViewController(otherVC, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("contentCell", forIndexPath: indexPath)as! ContentTableViewCell
        cell.configure(contents[indexPath.row])
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contents.count
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.pushToOtherController()
    }
}

extension HomeViewController: TurnPlayDelegate {
    func didSelectPage(page: Int) {
        self.pushToOtherController()
    }
    
    func currentPage(page: Int) {
        
    }
}
