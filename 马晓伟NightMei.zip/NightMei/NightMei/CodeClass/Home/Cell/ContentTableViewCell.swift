//
//  ContentTableViewCell.swift
//  NightMei
//
//  Created by luxtmxw on 16/10/1.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit

class ContentTableViewCell: UITableViewCell {
    
    var mainImg: UIImageView!
    var mainLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.initFrame()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initFrame() {
        self.selectionStyle = .None
        
        let topView = UIView(frame: CGRectMake(0,0,kScreenWidth,3.Sh()))
        topView.backgroundColor = Color_666
        contentView.addSubview(topView)
        
        
        mainImg = UIImageView(frame: CGRectMake(0,3.Sh(),kScreenWidth,174.Sh()))
        contentView.addSubview(mainImg)
        
        mainLbl = UILabel()
        mainLbl.setFrameByCenter(CGRectMake(
            kScreenWidth/2,177.Sh()/2,kScreenWidth-100,40))
        mainLbl.font = UIFont.boldSystemFontOfSize(20)
        mainLbl.textColor = UIColor.whiteColor()
        mainLbl.textAlignment = .Center
        mainImg.addSubview(mainLbl)
    }
    
    func configure(content: Content) {
        mainImg.sd_setImageWithURL(NSURL(string: content.imgUrl), placeholderImage: UIImage(named: "3"))
//        mainBtn.sd_setImageWithURL((NSURL(string: content.imgUrl), forState: UIControlState.Normal, placeholderImage: UIImage(named: "3")))
        if content.imgUrl == "" {
            mainLbl.text = ""
        }else {
            mainLbl.text = content.title
        }
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
