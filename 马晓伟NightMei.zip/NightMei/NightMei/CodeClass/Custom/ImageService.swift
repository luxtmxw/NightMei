//
//  ImageUploadService.swift
//  CteemoCN
//
//  Created by Wang Yu on 7/17/15.
//  Copyright (c) 2015 bintao. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
//ImageService单例
let ImageServiceInstance = ImageService.sharedInstance
//MARK: 图片上传和加载接口
class ImageService: NSObject {
    class var sharedInstance: ImageService {
        struct Singleton {
            static let instance = ImageService()
        }
        return Singleton.instance
    }
    
    //MARK: 网络加载图片
    func mcLoadImgURL(urlString: String!, handle: (UIImage?) -> Void){
        if urlString == nil {
            handle(nil)
            return
        }
        if let url = NSURL(string: urlString) {
            let request:NSURLRequest = NSURLRequest(URL:url)
            NSURLConnection.sendAsynchronousRequest(request, queue: NSOperationQueue.mainQueue(), completionHandler: { (response, data, error) -> Void in
                if data != nil{
                    if let img = UIImage(data: data!){
                        handle(img)
                        return
                    }
                }
                print("error: no image")
                handle(nil)
            })
        }else{
            print("error: wrong url")
            handle(nil)
        }
    }
    
//    //MARK: 上传单张图片
//    let domain = "http://7xkeab.com2.z0.glb.qiniucdn.com"
//    func imageUpLoadBlock(image: UIImage, handle: QNUpProgressHandler, finishHandler: (String!) -> Void) {//add by mc...
//        let requestURL = "\(Http_main)\(version_1)/user/upload-token"
//        
//        AlamofireInstance.request(.GET, requestURL) { (response, result) -> Void in
//            if response?.statusCode == 200 {
//                if result.value != nil {
//                    let json = JSON(result.value!)
//                    let token = json["token"].string
//                    let upManager = QNUploadManager()
//                    
//                    let imageData = UIImageJPEGRepresentation(image, 0.4)
//                    let uuid = NSUUID().UUIDString
//                    let key = "poster/\(uuid)"
//                    
//                    let opt = QNUploadOption { (key, percent) -> Void in
//                        handle(key, percent)
//                    }
//                    upManager.putData(imageData, key: key, token: token, complete: { (info, key, response) -> Void in
//                        print(response)
//                        let url = "\(self.domain)/\(key)"
//                        finishHandler(url)
//                        }, option: opt)
//                }
//            }else {
//                finishHandler(nil)
//            }
//        }
//    }
//    
//    //MARK: - 批量上传图片
//    func batchUploadImags(images: [UIImage], zoom: CGFloat, handle: QNUpProgressHandler, finishHandler: ([String]?) -> Void) {
//        let requestURL = "\(Http_main)\(version_1)/user/upload-token"
//        
//        AlamofireInstance.request(.GET, requestURL) { (response, result) -> Void in
//            if response?.statusCode == 200 {
//                if result.value != nil {
//                    let json = JSON(result.value!)
//                    let token = json["token"].string
//                    let upManager = QNUploadManager()
//                    var current: Int = 0
//                    var urls = [String]()
//                    
//                    if images.count == 0 {
//                        finishHandler(urls)
//                        return
//                    }else {
//                        let opt = QNUploadOption { (key, percent) -> Void in
//                            handle(key, percent)
//                        }
//                        for i in 0..<images.count {
//                            dispatch_async(GlobalQueue, {
//                                let image = images[i]
//                                let uuid = NSUUID().UUIDString
//                                let key = "poster/\(uuid)"
//                                let imageData = UIImageJPEGRepresentation(image, zoom)
//                                upManager.putData(imageData, key: key, token: token, complete: { (info, key, response) -> Void in
//                                    let url = "\(self.domain)/\(key)"
//                                    print(url)
//                                    urls.append(url)
//                                    current += 1
//                                    if current == images.count {
//                                        finishHandler(urls)
//                                    }
//                                    }, option: opt)
//                            })
//                        }
//                    }
//                }
//            }else {
//                finishHandler(nil)
//            }
//        }
//    }
}
