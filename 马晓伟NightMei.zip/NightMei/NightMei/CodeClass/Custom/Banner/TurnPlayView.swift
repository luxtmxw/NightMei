//
//  TurnPlayView.swift
//  CteemoCN
//
//  Created by MrMessy on 16/4/26.
//  Copyright © 2016年 bintao. All rights reserved.
//

import UIKit

@objc protocol TurnPlayDelegate: class {
    optional func currentPage(page: Int)
    optional func didSelectPage(page: Int)
}

//MARK: - 轮播视图
class TurnPlayView: UIView, UIScrollViewDelegate {
    
    weak var delegate: TurnPlayDelegate!
    /** 滚动视图 */
    private var scrollview: UIScrollView!
    /** 分页视图 */
    var pageControl: UIPageControl!
    /** 计时器 */
    var timer: NSTimer!
    
    var banners = [Banner]() { didSet { self.setBanners() }}
    var duration: NSTimeInterval! { didSet { self.setDuration() }}
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clearColor()
    }
    
    //MARK: - Private
    /**
     *  设置广告视图
     */
    private func setBanners() {
        for view in self.subviews {
            view.removeFromSuperview()
        }
        //滚动视图
        scrollview = UIScrollView(frame: bounds)
        scrollview.scrollsToTop = false
        scrollview.showsVerticalScrollIndicator = false
        scrollview.showsHorizontalScrollIndicator = false
        scrollview.pagingEnabled = true
        scrollview.delegate = self
        addSubview(scrollview)
        //添加点击手势
        let tap = UITapGestureRecognizer(target: self, action: "didCliclPageView")
        scrollview.addGestureRecognizer(tap)
        //分页视图
        pageControl = UIPageControl()
        pageControl.setFrameByCenter(CGRectMake(kScreenWidth/2,bounds.height - 10,30,20))
        pageControl.numberOfPages = banners.count
        pageControl.currentPage = 0
        addSubview(pageControl)
        
        var contentSize: CGSize = CGSizeMake(0, 0)
        var startPoint: CGPoint = CGPointMake(0, 0)
        if banners.count >= 1 {//多张图片
            for i in 0..<banners.count + 2 {
                let imageView = TurnPlayImageView(frame: CGRectMake(CGFloat(i) * bounds.width, 0, bounds.width, bounds.height))
                if i == 0 {
                    //第一个imageview放最后一张
                    imageView.banner = banners[banners.count - 1]
                }else if i == banners.count + 1 {
                    //最后一个imageview放第一张
                    imageView.banner = banners[0]
                }else {
                    //4，1，2，3，4，1类似
                    imageView.banner = banners[i - 1]
                }
                scrollview.addSubview(imageView)
                contentSize = CGSizeMake(CGFloat(banners.count + 2) * bounds.width, 0)
                startPoint = CGPointMake(bounds.width, 0)
            }
        }else {//0张图片
            let imageView = TurnPlayImageView(frame: CGRectMake(0, 0, bounds.width, bounds.height))
            imageView.banner = nil
            addSubview(imageView)
        }
        //开始的偏移量跟内容尺寸
        scrollview.contentOffset = startPoint
        scrollview.contentSize = contentSize
    }
    /**
     *  设置播放时间
     */
    private func setDuration() {
        if timer != nil {
            timer.invalidate()
        }
        self.startTimer()
    }
    //
    
    //MARK: - Timer
    func startTimer() {
        if duration == nil {
            timer = NSTimer(timeInterval: 3.0, target: self, selector: "updateTimer", userInfo: nil, repeats: true)
        }else {
            timer = NSTimer(timeInterval: duration, target: self, selector: "updateTimer", userInfo: nil, repeats: true)
        }
        NSRunLoop.currentRunLoop().addTimer(timer, forMode: NSRunLoopCommonModes)//UITrackingRunLoopMode//NSRunLoopCommonModes
    }
    
    func updateTimer() {
        print("aaaaa")
        let newOffset = CGPointMake(scrollview.contentOffset.x + CGRectGetWidth(scrollview.frame), 0)
        scrollview.setContentOffset(newOffset, animated: true)
    }
    //
    
    //MARK: - UITapGestureRecognizer
    func didCliclPageView() {
        self.delegate?.didSelectPage!(pageControl.currentPage)
        print(pageControl.currentPage)
    }
    
    //MARK: - UIScrollViewDelegate
    /**
     *  滚动中
     */
    func scrollViewDidScroll(scrollView: UIScrollView) {
        if scrollview.contentOffset.x < bounds.width {
            scrollview.setContentOffset(CGPointMake(bounds.width * CGFloat(banners.count + 1), 0), animated: false)
        }
        if scrollview.contentOffset.x > bounds.width * CGFloat(banners.count + 1) {
            scrollview.setContentOffset(CGPointMake(bounds.width, 0), animated: false)
        }
        var pageCount = Int(scrollview.contentOffset.x / bounds.width)
        
        if pageCount > banners.count {
            pageCount = 0
        }else if pageCount == 0 {
            pageCount = Int(banners.count - 1)
        }else {
            pageCount -= 1
        }
        self.delegate?.currentPage!(pageCount)
        pageControl.currentPage = pageCount
    }
    /**
     *  开始拖动
     */
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        
        timer.invalidate()
    }
    /**
     *  结束拖动
     */
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        self.startTimer()
    }
    //
}
