
import UIKit
import SwiftyJSON

protocol BannerModelDelegate {
    func imageChange(banner: Banner)
}

enum BannerStyle {
    case Video, //视频
    WeChat, //微信文章
    Article, //普通文章
    Raider, //攻略
    Report, //战报
    Tournament, //赛事
    draw,    //抽奖
    exchange    //兑换
}

class Banner: NSObject {
    
    var delegate: BannerModelDelegate?
//    var id: Int!
//    var title: String!
//    var type: String!
//    var type_id: String!
//    var gameId: String!
//    var position: String!
//    var pic: NSURL!
//    var pictureURL: String!
//    var content: String!
//    var createTime: String!
//    var updateTime: String!
//    var summary: String!
//    var style = BannerStyle.Article
    var image: UIImage!
    var imgUrl: String!
    
    convenience init(json: JSON) {
        self.init()
        self.imgUrl = json["picturePath"].stringValue
//        self.id = json["id"].intValue
//        self.title = json["title"].stringValue
//        self.type = json["type"].stringValue
//        self.type_id = json["type_id"].stringValue
//        self.gameId = json["game_id"].stringValue
//        self.position = json["position"].stringValue
//        self.pic = NSURL(string: json["pic"].stringValue)
//        self.pictureURL = json["pic"].stringValue
//        self.content = json["content"].stringValue
//        self.createTime = json["created_at"].stringValue
//        self.updateTime = json["updated_at"].stringValue
//        self.summary = json["summary"].stringValue
        ImageServiceInstance.mcLoadImgURL(json["pic"].stringValue) { (img) -> Void in
            self.image = img
            self.delegate?.imageChange(self)
        }
//        switch self.type {
//        case "article":
//            style = BannerStyle.Article
//        case "weChat":
//                style = BannerStyle.WeChat
//        case "video":
//            style = BannerStyle.Video
//        case "raider":
//            style = BannerStyle.Raider
//        case "report":
//            style = BannerStyle.Report
//        case "tournament":
//            style = BannerStyle.Tournament
//        default:
//            style = BannerStyle.WeChat //默认是WeChat
//            break
//        }
    }
    
}
