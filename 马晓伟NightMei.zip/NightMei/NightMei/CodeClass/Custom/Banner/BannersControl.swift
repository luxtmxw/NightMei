//
//  BannersControl.swift
//  CteemoCN
//
//  Created by MrMessy on 16/3/29.
//  Copyright © 2016年 bintao. All rights reserved.
//

import UIKit

//MARK: - 广告位控制器
class BannersControl: UIView {

    var bannerView: TurnPlayerView! //广告位视图
    var pageControl: UIPageControl! //分页控制器
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    convenience init() {
        self.init(frame: CGRectMake(0, 0, UIScreen.mainScreenWidth, 160))
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = Color_background
        //广告位视图
        bannerView = TurnPlayerView()
        bannerView.frame = bounds
        bannerView.backgroundColor = Color_background
        addSubview(bannerView)
        //分页控制器
        pageControl = UIPageControl(frame: CGRectMake(bounds.width - 50, 140, 30, 20))
        addSubview(pageControl)
    }
    
    //MARK: - 配置数据
    func configure(banners: [Banner]) {
        self.bannerView.bannerArray = banners
        self.bannerView.pageControll = pageControl
        self.bannerView.initTurnPlayView()
    }
}
