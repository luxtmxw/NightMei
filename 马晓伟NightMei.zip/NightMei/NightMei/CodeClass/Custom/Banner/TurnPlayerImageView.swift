import UIKit

class TurnPlayerImageView: UIImageView, BannerModelDelegate {
    var turnPlayer: Banner!{
        didSet{
            self.didSetTurnPlayer()
        }
    }
    
    var titleView: UIImageView!
    var title: UILabel! //新闻标题
    var type: UILabel! //新闻类型
    
    let progressIndicatorView = CircularLoaderView(frame: CGRectZero)
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        addSubview(self.progressIndicatorView)
        progressIndicatorView.frame = bounds
        progressIndicatorView.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.userInteractionEnabled = true
        addSubview(self.progressIndicatorView)
        progressIndicatorView.frame = bounds
        progressIndicatorView.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        
        titleView = UIImageView(frame: CGRectMake(0, bounds.height - 30, bounds.width, 30))
        titleView.image = UIImage(named: "广告位字体背景图")
        addSubview(titleView)
        
        type = UILabel(frame: CGRectMake(12, 6, 33, 18))
        type.textAlignment = .Center
        type.textColor = UIColor.whiteColor()
        type.font = UIFont.systemFontOfSize(12)
        type.layer.cornerRadius = 2.0
        type.clipsToBounds = true
        titleView.addSubview(type)
        
        title = UILabel(frame: CGRectMake(type.endX + 10, 5, bounds.width - type.endX - 20, 20))
        title.textAlignment = .Left
        title.textColor = UIColor.whiteColor()
        title.font = UIFont.systemFontOfSize(14)
        titleView.addSubview(title)
    }
    
    func loadFromURL(url: NSURL) {
        self.sd_setImageWithURL(url, placeholderImage: self.image, options: .CacheMemoryOnly, progress: { [weak self](receivedSize, expectedSize) -> Void in
            self!.progressIndicatorView.progress = CGFloat(receivedSize)/CGFloat(expectedSize)
            }) { [weak self](image, error, _, _) -> Void in
                self!.progressIndicatorView.reveal()
        }
    }
   
    
    convenience init() {
        self.init(frame: CGRectZero)
    }

    
    private func didSetTurnPlayer() {
        if self.turnPlayer == nil{
            return
        }
        
//        if self.turnPlayer.image == nil {
//            self.loadFromURL(self.turnPlayer.pic)
//        }else{
//            self.image = self.turnPlayer.image
//        }
        titleView.frame = CGRectMake(0, bounds.height - 30, bounds.width, 30)
        type.frame = CGRectMake(12, 6, 33, 18)
        title.frame = CGRectMake(type.endX + 10, 5, bounds.width - type.endX - 20, 20)
//        title.text = self.turnPlayer.title
//        type.text = self.turnPlayer.type == "tournament" ? "赛事" : "资讯"
//        type.backgroundColor = self.turnPlayer.type == "tournament" ? Color_FF9500 : UIColor.colorWithHexCode("00BFFF")
    }
    
    func imageChange(banner: Banner) {
//        self.sd_setImageWithURL(<#T##url: NSURL!##NSURL!#>, placeholderImage: <#T##UIImage!#>, options: <#T##SDWebImageOptions#>, completed: <#T##SDWebImageCompletionBlock!##SDWebImageCompletionBlock!##(UIImage!, NSError!, SDImageCacheType, NSURL!) -> Void#>)
//        
//        self.sd_setImageWithURL(url, placeholderImage: nil, options: .CacheMemoryOnly, progress: { [weak self](receivedSize, expectedSize) -> Void in
//            self!.progressIndicatorView.progress = CGFloat(receivedSize)/CGFloat(expectedSize)
//            }) { [weak self](image, error, _, _) -> Void in
//                self!.progressIndicatorView.reveal()
//        }
//        self.image = banner.image
    }
    
}
