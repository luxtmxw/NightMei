
import UIKit

class CommentView: UIView {

    var commentText: UITextField!
    var commentButton: UIButton!
    var bottomLine: UIView!
    
    func initCommentView(type: Int){
        self.backgroundColor = UIColor.whiteColor()
        
        self.bottomLine = UIView()
        self.bottomLine.frame = CGRectMake(0, 0, UIScreen.mainScreenWidth, 0.5)
        self.bottomLine.backgroundColor = Color_b3
        self.addSubview(self.bottomLine)
        
        self.commentButton = UIButton()
        self.commentButton.frame = CGRectMake(UIScreen.mainScreenWidth - 71 - 15.Sw(), (self.frame.height-35)/2, 71, 35)
        self.commentButton.setWane(4)
        self.commentButton.setBorder(Color_b3, width: 1.0)
        self.commentButton.titleLabel?.font = UIFont.systemFontOfSize(14)
        if type == 1{
            self.commentButton.setTitle("原文", forState: UIControlState.Normal)
            self.commentButton.setTitleColor(Color_b3, forState: UIControlState.Normal)
        }else{
            self.commentButton.setTitle("193", forState: UIControlState.Normal)
            self.commentButton.setTitleColor(Color_button, forState: UIControlState.Normal)
        }
        
        self.addSubview(self.commentButton)
        
        self.commentText = UITextField()
        self.commentText.frame = CGRectMake(15.Sw(), (self.frame.height-35)/2, self.commentButton.frame.origin.x - 10 - 15.Sw(), 35)
        self.commentText.backgroundColor = UIColor.whiteColor()

        self.commentText.setWane(17)
        self.commentText.setBorder(Color_b3, width: 1)
        self.commentText.placeholder = "点击评论"
        self.commentText.font = UIFont.systemFontOfSize(16)
        self.commentText.addLeftBlank(10)
        self.addSubview(commentText)
    }
}
