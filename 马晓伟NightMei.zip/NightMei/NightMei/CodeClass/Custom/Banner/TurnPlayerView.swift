import UIKit
protocol TurnPlayerViewDelegate {
    func didImageTap(i:Int)
}

class TurnPlayerView: UIScrollView, UIScrollViewDelegate {
    
    var bannerArray = [Banner]()
    var timer : NSTimer?
    var turnDelegate: TurnPlayerViewDelegate?
    var turnCount: Int = 0
    var pageControll = UIPageControl()
    
    func initTurnPlayView() {
        self.backgroundColor = Color_background
        turnCount = self.bannerArray.count

        self.delegate = self
        self.scrollEnabled = true
        self.showsHorizontalScrollIndicator = false
        self.alwaysBounceHorizontal = true
        self.pagingEnabled = true
        if turnCount == 0 {
            self.contentSize.width = frame.width
            self.contentOffset.x = 0
            pageControll.numberOfPages = 0
            for view in self.subviews {
                view.removeFromSuperview()
            }
            let noImageView = UIImageView(frame: CGRectMake(0, 0, frame.width, frame.height))
            noImageView.image = UIImage(named: "1")
            addSubview(noImageView)
            self.scrollEnabled = false
            if timer != nil {
                timer!.invalidate()
            }
        }else{
            self.createSubView()
            self.contentSize.width = frame.width * 3
            self.contentOffset.x = frame.width
            if turnCount == 1 {
                pageControll.numberOfPages = 0
                self.scrollEnabled = false
            }else {
                timer = NSTimer.scheduledTimerWithTimeInterval(4.0, target: self, selector: "TurnPlayerView.didTurnPlay", userInfo: nil, repeats: false)
                pageControll.numberOfPages = turnCount
                self.scrollEnabled = true
            }
        }
    }
    
    var currImageView = TurnPlayerImageView()
    var prevImageView = TurnPlayerImageView()
    var nextImageView = TurnPlayerImageView()
    
    func createSubView(){//创建相应的界面
        currImageView.frame = CGRectMake(frame.width, 0, frame.width, frame.height)
        currImageView.turnPlayer = self.bannerArray[0]
        self.addSubview(currImageView)
        currImageView.userInteractionEnabled = true
        
        let tap = UITapGestureRecognizer(target: self, action: "TurnPlayerView.didImg")
        self.currImageView.addGestureRecognizer(tap)
        
        nextImageView.frame = CGRectMake(frame.width*2, 0, frame.width, frame.height)
        if turnCount == 1 {
            nextImageView.turnPlayer = self.bannerArray[0]
        }else{
            nextImageView.turnPlayer = self.bannerArray[1]
        }
        self.addSubview(nextImageView)
        self.insertSubview(nextImageView, atIndex: 0)
        
        prevImageView.frame = CGRectMake(0, 0, frame.width, frame.height)
        prevImageView.turnPlayer = self.bannerArray[turnCount-1]
        self.addSubview(prevImageView)
    }
    
    var i = 0
    func scrollViewDidScroll(scrollView: UIScrollView) {
        let offset = self.contentOffset.x
        if turnCount != 0 {
            if self.nextImageView.turnPlayer == nil || self.prevImageView.turnPlayer == nil{
                if i == turnCount-1{
                    nextImageView.turnPlayer = self.bannerArray[0]
                }else{
                    nextImageView.turnPlayer = self.bannerArray[i+1]
                }
                
                if i == 0 {
                    prevImageView.turnPlayer = self.bannerArray[turnCount-1]
                }else{
                    prevImageView.turnPlayer = self.bannerArray[i-1]
                }
            }
            if offset <= 0 {
                scrollView.setContentOffset(CGPoint(x: 0, y: scrollView.contentOffset.y), animated: false)
            }else if offset >= scrollView.frame.width*2{
                scrollView.setContentOffset(CGPoint(x: scrollView.frame.width*2, y: scrollView.contentOffset.y), animated: false)
            }
            if  offset == 0 {
                currImageView.turnPlayer = prevImageView.turnPlayer
                scrollView.contentOffset = CGPointMake(scrollView.bounds.size.width, 0)
                prevImageView.turnPlayer = nil
                if i == 0{
                    i = turnCount-1
                }else{
                    i -= 1
                }
                scrollView.contentOffset.x = scrollView.frame.width
            }
            
            if offset == scrollView.bounds.size.width * 2{
                currImageView.turnPlayer = nextImageView.turnPlayer
                scrollView.contentOffset = CGPointMake(scrollView.bounds.size.width, 0)
                nextImageView.turnPlayer = nil
                if i == turnCount-1 {
                    i = 0
                }else{
                    i += 1
                }
                scrollView.contentOffset.x = scrollView.frame.width
            }
            pageControll.currentPage = i
            if turnCount > 1 {
                timer?.invalidate()
                timer = NSTimer.scheduledTimerWithTimeInterval(4.0, target: self, selector: "TurnPlayerView.didTurnPlay", userInfo: nil, repeats: false)
            }
        }
    }
    
    func didTurnPlay() {
        if turnCount != 0 {
            self.setContentOffset(CGPoint(x: frame.width*2, y: self.contentOffset.y), animated: true)
        }
    }
    
    func didImg() {
        if turnCount == 1 {
            i = 0
        }
        self.turnDelegate?.didImageTap(i)
    }
}
