//
//  TurnPlayImageView.swift
//  CteemoCN
//
//  Created by MrMessy on 16/4/27.
//  Copyright © 2016年 bintao. All rights reserved.
//

import UIKit

//MARK: - 轮播图片视图
class TurnPlayImageView: UIView {

    /** 图片 */
    var imageView: UIImageView!
    /** 标题视图 */
    var titleView: UIImageView!
    /** 标题 */
    var title: UILabel!
    /** 类型 */
    var type: UILabel!
    var banner: Banner! { didSet { self.configure() } }
    
    //MARK: - Override
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clearColor()
        //图片
        imageView = UIImageView(frame: bounds)
        addSubview(imageView)
        //标题视图
        titleView = UIImageView(frame: CGRectMake(0, bounds.height - 30, bounds.width, 30))
        titleView.image = UIImage(named: "广告位字体背景图")
        addSubview(titleView)
        //标题
        type = UILabel(frame: CGRectMake(12, 6, 33, 18))
        type.textAlignment = .Center
        type.textColor = UIColor.whiteColor()
        type.font = Font.systemFontOfSize(12.0)
        type.layer.cornerRadius = 2.0
        type.clipsToBounds = true
        titleView.addSubview(type)
        //类型
        title = UILabel(frame: CGRectMake(type.endX + 10, 5, bounds.width - type.endX - 20, 20))
        title.textAlignment = .Left
        title.textColor = UIColor.whiteColor()
        title.font = Font.systemFontOfSize(14.0)
        titleView.addSubview(title)
    }
    //
    
    //MARK: - Private
    /** 配置数据 */
    private func configure() {
        if banner != nil {
            
            guard banner.image == nil else {
                imageView.image = banner.image
                return
            }
            
            imageView.sd_setImageWithURL(NSURL(string: banner.imgUrl), placeholderImage: defaultUserBackground)
//            title.text = banner.title
//            switch banner.style {
//            case .Video://视频
//                type.text = "视频"
//                type.backgroundColor = Color_00BFFF
//            case .Tournament://赛事
//                type.text = "赛事"
//                type.backgroundColor = Color_FF9500
//            case .Raider://攻略
//                type.text = "攻略"
//                type.backgroundColor = Color_00BFFF
//            case .Report://战报
//                type.text = "战报"
//                type.backgroundColor = Color_00BFFF
//            case .WeChat://资讯
//                type.text = "资讯"
//                type.backgroundColor = Color_00BFFF
//            case .draw:
//                type.text = "抽奖"
//                type.backgroundColor = Color_00BFFF
//            case .exchange:
//                type.text = "兑换"
//                type.backgroundColor = UIColor.colorWithHexCode("ff9800")
//            default:
//                type.text = "资讯"
//                type.backgroundColor = Color_00BFFF
//                break
//            }
        }else {
            imageView.image = defaultUserBackground
        }
    }
}
