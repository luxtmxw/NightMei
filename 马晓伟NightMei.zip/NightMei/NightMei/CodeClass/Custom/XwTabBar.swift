//
//  XwTabBar.swift
//  CteemoCM
//
//  Created by luxtmxw on 16/3/23.
//  Copyright © 2016年 Bintao. All rights reserved.
//

import UIKit

class XwTabBar: UITabBar {
    
    lazy var midBtn: UIButton = {
        var btn = UIButton()
        btn.sizeToFit()
        btn.setBackgroundImage(UIImage(named: "6"), forState: .Normal)
        return btn
    }()
    var midLbl: UILabel!
    
    convenience init(frame: CGRect, target: AnyObject, btnAction: Selector) {
        self.init()
        self.frame = frame
//        self.backgroundColor = UIColor.redColor()
        self.shadowImage = UIImage()
        self.translucent = false
        midBtn.addTarget(target, action: btnAction, forControlEvents: .TouchUpInside)
        self.addSubview(midBtn)
        
        midLbl = UILabel()
        midLbl.labelInit("收付款", fontSize: 9, textColor: Color_206, alignmentStyle: .Center, addSubView: self)

    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        var tabFrame = self.frame
        tabFrame.size.height = 59.5
        tabFrame.origin.y = kScreenHeight - 59.5;
        self.frame = tabFrame
        
        let w:CGFloat = self.bounds.size.width
        let h:CGFloat = self.bounds.size.height
        
        var btnX:CGFloat = 0
        let btnY:CGFloat = 0
        let btnW:CGFloat = w / 5
        let btnH:CGFloat = h
        
        var i: CGFloat = 0
        for item in self.subviews {
            if item.isKindOfClass(NSClassFromString("UITabBarButton")!) {
                btnX = i * btnW
                item.frame = CGRectMake(btnX, btnY, btnW, btnH)
                
                if i == 1 {
                    i += 1
                }
                
                i += 1
            }
            
            if item.isKindOfClass(NSClassFromString("_UITabBarBackgroundView")!) {
                item.backgroundColor = UIColor.clearColor()
            }
            
            if item.isKindOfClass(NSClassFromString("UIImageView")!) {
                item.hidden = true
            }
            
            
            
        }
        
        let imgView = UIImageView(image: UIImage(named: "0"))
        imgView.frame = CGRectMake(0, 0, self.frame.width, self.frame.height)
        self.insertSubview(imgView, atIndex: 1)
        
//        self.midBtn.frame = CGRectMake(0, 0, btnH - 4, btnH - 4)
//        self.midBtn.center = CGPointMake(w * 0.5, h * 0.5)
        self.midBtn.setFrameByCenter(CGRectMake(w * 0.5, h * 0.5 - 5.25, 31.Sw(), 31.Sw()))
        
        self.midLbl.setFrameByCenter(CGRectMake(w * 0.5, midBtn.endY + 10, 40, 15))
        
    }
}
