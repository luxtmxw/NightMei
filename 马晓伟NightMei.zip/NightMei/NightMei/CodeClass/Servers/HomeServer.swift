//
//  HomeServer.swift
//  NightMei
//
//  Created by luxtmxw on 16/10/1.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

let HomeServerInstance = HomeServer.homeserverInstance
class HomeServer: NSObject {
    static let homeserverInstance = HomeServer()
    
    //MARK - 登录
    func login(succeed:(String) -> Void, fail: () -> Void) {
        let requestURL = "http://admin.haoju.me:8082/kpbase/api/login.json?loginName=13120685503&password=111111&siteID=8a2f462a55df494e0155e3f0d7b13de8&deviceID=8a2f462a55ed78d00155edf26152148f"
        AlamofireInstance.request(.GET, requestURL, encoding: .JSON) { (response, data) -> Void in
            guard data.value != nil else {
                fail()
                return
            }
            
            if response?.statusCode == 200 {
                let json = JSON(data.value!)
                let sessionID = json["body"]["sessionID"].stringValue
                succeed(sessionID)
            }else {
                fail()
            }
        }
    }
    
    //MARK - 轮播图
    func getSwiper(sessionID: String, succeed: ([Banner]) -> Void, fail: () -> Void) {
        let requestUrl = "http://admin.haoju.me:8082/kpbase/api/getFocusList.json?sessionID=\(sessionID)&focusID=854fea47c4214036b5dc137494c3f6ec"
        AlamofireInstance.request(.GET, requestUrl, encoding: .JSON) { (response, data) -> Void in
            guard data.value != nil else {
                fail()
                return
            }
            
            if response?.statusCode == 200 {
                let json = JSON(data.value!)
                var imgs = [Banner]()
                json["body"]["data"].array!.forEach{
                    imgs.append(Banner(json: $0))
                }
                succeed(imgs)
            }else {
                fail()
            }
        }
    }
    
    //MARK - 分类
    func getCategory(sessionID: String, succeed: (content: [Content] ) -> Void, fail: () -> Void) {
        let requestURL = "http://admin.haoju.me:8082/kpbase/api/getcategorylist.json?sessionID=\(sessionID)&parentID=2a89882dffa242158a5e170215f351ad&categoryID=2a89882dffa242158a5e170215f351ad&depth=4"
        AlamofireInstance.request(.GET, requestURL, encoding: .JSON) { (response, data) -> Void in
            guard data.value != nil else {
                fail()
                return
            }
            
            if response?.statusCode == 200 {
                let json = JSON(data.value!)
                var contents = [Content]()
                let contentsJson = json["body"]["categorys"]["data"]["nodes"].arrayValue
                contentsJson.forEach {
                    contents.append(Content(json: $0))
                }
                succeed(content: contents)
            }else {
                fail()
            }
        }
    }
    
    
}
